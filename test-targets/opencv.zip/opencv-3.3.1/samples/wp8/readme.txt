Building OpenCV Windows Phone Samples
=====================================

Samples are created to run against x86 architecture OpenCV binaries.

Please follow the instructions in "platforms/winrt/readme.txt" to generate and build OpenCV for Windows Phone 8.0/8.1